/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mensajeria;



/**
 *
 * @author Manuel
 */
public class Celular {
    private final String[] bandejaEntrada;
    
    public Celular(int maxSize){
        this.bandejaEntrada = new String[maxSize];
    }
    
    public void enviarMensaje(String contenido, Celular receptor){
        receptor.recibirMensaje(contenido);
    }
    
    private boolean recibirMensaje(String contenido){
        for (int i = 0; i < this.bandejaEntrada.length; i++) {
            if(this.bandejaEntrada[i]==null){
                this.bandejaEntrada[i] = contenido;
                return true;
            }
        }
        return false;
    }
    
    
    public int cantidadMensajesActuales(){
        for (int i = 0; i < this.bandejaEntrada.length; i++) {
            if(this.bandejaEntrada[i]==null){
                return i;
            }
        }
        return this.bandejaEntrada.length;
    }

    public String[] getBandejaEntrada() {
        return this.bandejaEntrada;
    }
}
