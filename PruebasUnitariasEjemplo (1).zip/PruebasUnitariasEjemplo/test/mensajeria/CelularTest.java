/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mensajeria;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Legion
 */
public class CelularTest {
    
    private Celular emisor;
    private Celular receptor;
    
    public CelularTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        this.receptor = new Celular(5);
        this.emisor = new Celular(5);
    }
    
    @After
    public void tearDown() {
        this.receptor = null;
        this.emisor = null;
    }

    
    @Test
    public void testEnviarMensaje() {
        
        String mensaje = "Saludos";
        
        this.emisor.enviarMensaje(mensaje, receptor);
        
        String checkMensaje = this.receptor.getBandejaEntrada()[0];
        
        assertTrue(mensaje.equals(checkMensaje));
        
    }

    @Test
    public void testMensajesActuales() {
        
        String mensaje1 = "Que tal";
        String mensaje2 = "Saludos";
        
        this.emisor.enviarMensaje(mensaje1, receptor);
        this.emisor.enviarMensaje(mensaje2, receptor);
        
        int inboxSize = receptor.cantidadMensajesActuales();
        
        //(valor esperado, valor obtenido)
        assertEquals(2, inboxSize);
        
    }
    
    
    
}
